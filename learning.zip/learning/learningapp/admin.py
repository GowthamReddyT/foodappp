from django.contrib import admin
from learningapp.models import UserDetails
# Register your models here.

admin.site.register(UserDetails)


