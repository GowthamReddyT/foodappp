from django.apps import AppConfig


class FoodsappConfig(AppConfig):
    name = 'foodsapp'
